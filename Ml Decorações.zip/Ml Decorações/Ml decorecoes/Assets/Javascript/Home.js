const H4FooterCreditos = document.getElementById('H4FooterCreditos')
const SpanCategoriasUm = document.getElementById('SpanCategoriasUm')
const SpanCategoriasDois = document.getElementById('SpanCategoriasDois')
const SpanCategoriasTrez = document.getElementById('SpanCategoriasTrez')
const BtnToggleCategorias = document.querySelectorAll('#BtnToggleCategorias')
const MenuFloat = document.getElementById('MenuFloat')

addEventListener('DOMContentLoaded', () => {
    const NewYear = new Date().getFullYear()

    H4FooterCreditos.textContent = `© ${NewYear} ML Decor Inc. All Rights Reserved.`
})

BtnToggleCategorias.forEach(Btn => {
    Btn.onclick = () => {
        if (MenuFloat.style.padding == "10px") {
            MenuFloat.style.padding = '0'
            MenuFloat.style.height = '0'

        }else {
            MenuFloat.style.padding = '10px'
            MenuFloat.style.height = 'auto'
        }

        SpanCategoriasUm.classList.toggle("SpanCategoriasUm")
        SpanCategoriasDois.classList.toggle("SpanCategoriasDois")
        SpanCategoriasTrez.classList.toggle("SpanCategoriasTrez")
    }
})