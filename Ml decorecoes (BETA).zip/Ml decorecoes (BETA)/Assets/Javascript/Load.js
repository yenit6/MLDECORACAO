// Exibe nome e sobrenome do usuário se estiverem salvos no localStorage
function PrintName() {
    const PrintNameUser = document.getElementById("PrintNameUser")
    const NomeSemLogon = "Login ou cadastro"

    const IntervalBusca = setInterval(() => {
        const Usuario = JSON.parse(localStorage.getItem("Usuario")) || []
        const Nome = Usuario[0]?.Nome
        const Sobrenome = Usuario[0]?.Sobrenome

        if (Nome && Sobrenome) {
            PrintNameUser.textContent = `${Nome} ${Sobrenome}`
            clearInterval(IntervalBusca)
        }else {
            PrintNameUser.textContent = NomeSemLogon
        }
    }, 500)
}

// Exibe ou oculta o botão "Voltar" dependendo da flag 'VoltarCompra'
window.addEventListener("DOMContentLoaded", () => {
    const BtnVoltarPage = document.getElementById("BtnVoltarPage")
    const veioDaCompra = localStorage.getItem("ButtonBack") === "true"

    BtnVoltarPage.style.display = veioDaCompra ? "block" : "none"

    BtnVoltarPage.onclick = () => {
        window.location.href = "Assets/Pages/Home.html"
    }
})

// Inicia o print do nome assim que a página carrega
PrintName()
